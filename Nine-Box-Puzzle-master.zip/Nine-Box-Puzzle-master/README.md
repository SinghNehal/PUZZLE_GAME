# Nine-Box-Puzzle
A simple game of Nine Box Puzzle written in Java Swing from scratch.
